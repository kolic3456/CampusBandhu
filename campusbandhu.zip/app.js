// --- GLOBAL DATA STORE ---
// Simulates a backend database for users, PGs, Messes, Notes, Books.
// In a real app, this would be fetched from a server.
const DB = {
    users: [], // Stores { name, email, password, role, gender?, contact?, listings: [] }
    pgs: [],   // Stores { id, type, name, location, price, features, occupancy, img, ownerEmail }
    messes: [], // Stores { id, type, name, location, price, menu, img, ownerEmail }
    notes: [],  // Stores { id, type, name, price, img, ownerEmail }
    books: []   // Stores { id, type, name, price, img, ownerEmail }
};

// Populate with some initial data for demonstration
DB.pgs.push({ id:1, type: 'pg', name: 'Shri Krishna PG', location: 'Near ABC College', price: 7500, features: 'AC, WiFi, Food', occupancy: 'girls', img: 'https://placehold.co/400x300/FFE4E6/7C2D12?text=Shri+Krishna+PG', ownerEmail: 'pgowner@campus.com' });
DB.pgs.push({ id:2, type: 'pg', name: 'Royal Boys Hostel', location: 'Sector 15', price: 8000, features: 'Gym, 2-Seater, WiFi\nFood Included (4 meals)', occupancy: 'boys', img: 'https://placehold.co/400x300/E0F2FE/0C4A6E?text=Royal+Boys+Hostel', ownerEmail: 'pgowner@campus.com' });
DB.messes.push({ id:1, type: 'mess', name: 'Ghar Ka Khana Mess', location: 'Alpha II Market', price: 3500, menu: 'Variety of North Indian dishes.\nMon: Rajma Chawal\nTue: Kadhi Pakoda\nWed: Chole Bhature', img: 'https://placehold.co/400x300/FEF3C7/92400E?text=Ghar+Ka+Khana', ownerEmail: 'messowner@campus.com' });
DB.notes.push({ id:1, type: 'note', name: 'Physics B.Tech 1st Year', price: 200, img: 'https://placehold.co/400x300/ECFDF5/065F46?text=Physics+Notes', ownerEmail: 'student@campus.com' });

// Add dummy users for quick testing
DB.users.push({ name: 'Alex Student', email: 'student@campus.com', password: 'password123', role: 'student', gender: 'male', listings: [] });
DB.users.find(u => u.email === 'student@campus.com').listings.push(DB.notes[0]); // Assign initial notes to student
DB.users.push({ name: 'Priya PG Owner', email: 'pgowner@campus.com', password: 'password123', role: 'pgOwner', contact: '9876543210', listings: [] });
DB.users.find(u => u.email === 'pgowner@campus.com').listings.push(DB.pgs[0], DB.pgs[1]); // Assign initial PGs to owner
DB.users.push({ name: 'Rohit Mess', email: 'messowner@campus.com', password: 'password123', role: 'messOwner', contact: '9988776655', listings: [] });
DB.users.find(u => u.email === 'messowner@campus.com').listings.push(DB.messes[0]); // Assign initial Mess to owner


// --- FEATURES CONFIGURATION ---
const LANDING_PAGE_FEATURES = [
    { id: 'find-pg', title: 'Find a PG', desc: 'Book your perfect stay', icon: 'home', page: 'page-listings', options: {dataType: 'pgs'} },
    { id: 'find-mess', title: 'Find a Mess', desc: 'Healthy, home-style food', icon: 'utensils', page: 'page-listings', options: {dataType: 'messes'} },
    { id: 'find-notes', title: 'Find Notes', desc: 'Get material from seniors', icon: 'file-text', page: 'page-listings', options: {dataType: 'notes'} },
    { id: 'find-books', title: 'Sale Books', desc: 'Buy & sell second-hand books', icon: 'book', page: 'page-listings', options: {dataType: 'books'} }
];

const STUDENT_DASHBOARD_FEATURES = [
    { id: 'find-pg', title: 'Find a PG', page: 'page-listings', options: {dataType: 'pgs'} },
    { id: 'find-mess', title: 'Find a Mess', page: 'page-listings', options: {dataType: 'messes'} },
    { id: 'find-books', title: 'Find Books', page: 'page-listings', options: {dataType: 'books'} },
    { id: 'find-notes', title: 'Find Notes', page: 'page-listings', options: {dataType: 'notes'} },
];

// --- HELPER FUNCTIONS ---
const formatOccupancy = (occ) => {
    if (occ === 'girls') return 'Girls Only';
    if (occ === 'boys') return 'Boys Only';
    return 'For Anyone';
};


// --- APPLICATION STATE ---
let appState = {
    isLoggedIn: false,
    currentUser: null, // Stores the logged-in user object from DB.users
    currentPage: 'page-landing',
    history: [{pageId: 'page-landing', options: {}}], // Stores objects {pageId, options}
    uploadedImageBase64: null // Temp store for image during form fill
};

const PROTECTED_PAGES = [
    'page-dashboard-student', 'page-dashboard-pgOwner', 'page-dashboard-messOwner',
    'page-sale-item', 'page-add-pg', 'page-add-mess', 'page-item-details' // Add details page as protected
];


// --- NAVIGATION FUNCTIONS ---
const navigateTo = (pageId, options = {}, fromGoBack = false) => {
    // Auth check for protected pages
    if (PROTECTED_PAGES.includes(pageId) && !appState.isLoggedIn) {
        // Use custom modal later if time allows
        alert("Please log in to access this feature.");
        // Store intended action for post-login redirect
        appState.intendedAction = { page: pageId, options: options };
        return navigateTo('page-auth');
    }

    // Role-specific access control
    if (appState.isLoggedIn) {
        const userRole = appState.currentUser.role;
        if (pageId.startsWith('page-dashboard-') && pageId !== `page-dashboard-${userRole}`) {
            alert(`Access Denied: You are a ${userRole} and cannot view this dashboard.`);
            return; // Prevent navigating to incorrect dashboard
        }
        if (pageId === 'page-sale-item' && userRole !== 'student') {
            alert('Only students can sell books or notes.');
            return;
        }
        if (pageId === 'page-add-pg' && userRole !== 'pgOwner') {
            alert('Only PG Owners can list PGs.');
            return;
        }
        if (pageId === 'page-add-mess' && userRole !== 'messOwner') {
            alert('Only Mess Owners can manage mess details.');
            return;
        }
    }


    // Hide all pages, then show the target page
    document.querySelectorAll('.page-view').forEach(p => p.classList.add('hidden'));
    const targetPage = document.getElementById(pageId);
    if (targetPage) targetPage.classList.remove('hidden');

    // Update history
    if (!fromGoBack) {
        // Clear history if navigating from an auth-protected page to a public one on logout
        if (!appState.isLoggedIn && !['page-auth', 'page-landing'].includes(pageId)) {
             appState.history = [{pageId: 'page-landing', options: {}}];
        } else {
             appState.history.push({pageId, options});
        }
    }
    appState.currentPage = pageId;

    // Trigger specific rendering logic for dynamic pages
    if (pageId === 'page-listings') renderListingsPage(options.dataType);
    if (pageId.startsWith('page-dashboard')) renderDashboard();

    // Handle rendering for the item details page
    if (pageId === 'page-item-details') {
        renderItemDetailsPage(options.itemId, options.itemType);
    }

    // Reset image preview on relevant forms
    if (['page-sale-item', 'page-add-pg', 'page-add-mess'].includes(pageId)) {
        appState.uploadedImageBase64 = null;
        let previewId = `image-preview-${pageId.replace('page-','')}`;
        const previewElement = document.getElementById(previewId); // Get element first
        if (previewElement) { // Check if element exists before setting src
            previewElement.src = 'https://placehold.co/600x400/E2E8F0/94A3B8?text=Image+Preview';
        }
    }

    window.scrollTo(0, 0); // Scroll to top on page navigation
};

const goBack = () => {
    if (appState.history.length <= 1) return navigateTo('page-landing');
    appState.history.pop(); // Remove current page
    const lastState = appState.history[appState.history.length - 1]; // Get previous page
    navigateTo(lastState.pageId, lastState.options, true); // Navigate back without adding to history
};

// Special navigation function for mobile menu to also close the menu
const mobileNavigate = (pageId, options = {}) => {
    navigateTo(pageId, options);
    const mobileMenu = document.getElementById('mobile-menu');
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    if (mobileMenu && mobileMenuButton) {
        mobileMenu.classList.add('hidden');
        const icon = mobileMenuButton.querySelector('i');
        icon.setAttribute('data-lucide', 'menu');
        lucide.createIcons();
    }
};


// --- AUTHENTICATION & USER MANAGEMENT ---
document.getElementById('auth-toggle-link').addEventListener('click', (e) => {
    e.preventDefault();
    const isLoginVisible = !document.getElementById('login-form').classList.contains('hidden');
    document.getElementById('login-form').classList.toggle('hidden');
    document.getElementById('register-form').classList.toggle('hidden');

    document.getElementById('auth-title').textContent = isLoginVisible ? 'Create an Account' : 'Login to CampusBandhu';
    document.getElementById('auth-toggle-text').textContent = isLoginVisible ? 'Already have an account?' : 'Don\'t have an account?';
    e.target.textContent = isLoginVisible ? 'Login' : 'Sign Up';

    // Reset forms and image previews
    document.getElementById('login-form').reset();
    document.getElementById('register-form').reset();
    document.getElementById('owner-contact-field').classList.add('hidden'); // Hide contact for students
    document.getElementById('student-gender-field').classList.add('hidden'); // Hide gender
});

document.getElementById('register-role').addEventListener('change', (e) => {
    const role = e.target.value;
    // Toggle contact field (hidden for student)
    document.getElementById('owner-contact-field').classList.toggle('hidden', role === 'student');
    document.getElementById('register-contact').required = (role !== 'student');

    // Toggle gender field (visible ONLY for student)
    document.getElementById('student-gender-field').classList.toggle('hidden', role !== 'student');
    document.getElementById('register-gender').required = (role === 'student');
});


document.getElementById('register-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const role = document.getElementById('register-role').value;
    // Get gender value only if role is student
    const gender = (role === 'student') ? document.getElementById('register-gender').value : undefined;

    const newUser = {
        name: document.getElementById('register-name').value,
        email: document.getElementById('register-email').value.toLowerCase(),
        password: document.getElementById('register-password').value,
        role: role,
        gender: gender, // Add gender field
        contact: role !== 'student' ? document.getElementById('register-contact').value : undefined,
        listings: [] // All users have a listings array, even if empty
    };
    if (DB.users.find(u => u.email === newUser.email)) {
        return alert('An account with this email already exists.');
    }
    DB.users.push(newUser);
    alert('Registration successful! Please log in with your new account.');
    // Switch back to login form and reset register form
    document.getElementById('auth-toggle-link').click(); // Simulates clicking to toggle back to login
});

document.getElementById('login-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('login-email').value.toLowerCase();
    const password = document.getElementById('login-password').value;
    const user = DB.users.find(u => u.email === email && u.password === password);
    if (user) {
        appState.isLoggedIn = true;
        appState.currentUser = user;
        if (appState.intendedAction) {
            navigateTo(appState.intendedAction.page, appState.intendedAction.options);
            appState.intendedAction = null;
        } else {
            navigateTo(`page-dashboard-${user.role}`);
        }
    } else {
        alert('Invalid email or password.');
    }
});

const handleLogout = () => {
    appState.isLoggedIn = false;
    appState.currentUser = null;
    appState.history = [{pageId: 'page-landing', options: {}}]; // Reset history on logout
    navigateTo('page-landing');
};


// --- DYNAMIC RENDERING FUNCTIONS ---
const renderDashboard = () => {
    if (!appState.currentUser) return;
    const user = appState.currentUser;
    const welcomeName = user.name.split(' ')[0]; // First name

    if (user.role === 'student') {
        document.getElementById('student-welcome').textContent = `Welcome back, ${welcomeName}!`;
        renderUserListings();
        renderFeatures('dashboard-grid-student', STUDENT_DASHBOARD_FEATURES);
    } else if (user.role === 'pgOwner') {
        document.getElementById('pg-welcome').textContent = `Welcome, ${welcomeName}!`;
        renderPGOwnerListings();
    } else if (user.role === 'messOwner') {
        document.getElementById('mess-welcome').textContent = `Welcome, ${welcomeName}!`;
        renderMessOwnerDetails();
    }
};

const renderUserListings = () => { // For Student Dashboard: My Zone
    const grid = document.getElementById('user-listings-grid');
    const emptyMsg = document.getElementById('user-listings-empty');
    grid.innerHTML = '';
    const userListings = appState.currentUser?.listings || [];

    if(userListings.length === 0) {
        emptyMsg.classList.remove('hidden');
        grid.classList.add('hidden');
    } else {
        emptyMsg.classList.add('hidden');
        grid.classList.remove('hidden');
        [...userListings].reverse().forEach(item => {
            grid.innerHTML += `
                <div class="bg-white p-4 rounded-lg border shadow-sm">
                    <img src="${item.img || 'https://placehold.co/400x300/E2E8F0/94A3B8?text=No+Image'}" class="rounded-md aspect-listing mb-2" alt="${item.name}">
                    <h4 class="font-semibold text-slate-800">${item.name}</h4>
                    <p class="text-slate-600 text-sm">Type: ${item.type === 'book' ? 'Book' : 'Notes'}</p>
                    <p class="text-lg font-bold text-green-600 mt-1">₹${item.price.toLocaleString('en-IN')}</p>
                </div>
            `;
        });
    }
};

const renderPGOwnerListings = () => { // For PG Owner Dashboard
    const grid = document.getElementById('pg-owner-listings-grid');
    const emptyMsg = document.getElementById('pg-owner-listings-empty');
    grid.innerHTML = '';
    const pgListings = appState.currentUser?.listings.filter(l => l.type === 'pg') || []; // PG Owner's specific listings

    if (pgListings.length === 0) {
        emptyMsg.classList.remove('hidden');
        grid.classList.add('hidden');
    } else {
        emptyMsg.classList.add('hidden');
        grid.classList.remove('hidden');
        [...pgListings].reverse().forEach(pg => {
            const occupancyText = formatOccupancy(pg.occupancy);
            const badgeColor = pg.occupancy === 'girls' ? 'bg-pink-100 text-pink-700' : (pg.occupancy === 'boys' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700');

            grid.innerHTML += `
                <div class="bg-white rounded-xl border overflow-hidden shadow-sm relative">
                    <img src="${pg.img || 'https://placehold.co/400x300/E2E8F0/94A3B8?text=No+Image'}" class="aspect-listing" alt="${pg.name}">
                    <span class="text-xs font-semibold px-2 py-1 ${badgeColor} rounded-full absolute top-3 right-3">${occupancyText}</span>
                    <div class="p-4">
                        <h4 class="text-xl font-bold text-slate-800">${pg.name}</h4>
                        <p class="text-slate-600 text-sm">${pg.location}</p>
                        <p class="text-2xl font-bold text-indigo-600 mt-2">₹${pg.price.toLocaleString('en-IN')}/month</p>
                        <p class="text-slate-700 text-sm mt-2">Features: ${pg.features}</p>
                        <button class="w-full mt-4 bg-indigo-500 text-white py-2 rounded-lg hover:bg-indigo-600">Edit Details</button>
                    </div>
                </div>
            `;
        });
    }
};

const renderMessOwnerDetails = () => { // For Mess Owner Dashboard
    const detailsCard = document.getElementById('mess-owner-details-card');
    const emptyMsg = document.getElementById('mess-owner-details-empty');

    const messDetails = appState.currentUser?.listings.find(l => l.type === 'mess'); // Assuming one mess per owner

    if (!messDetails) {
        emptyMsg.classList.remove('hidden');
        detailsCard.classList.add('hidden');
    } else {
        emptyMsg.classList.add('hidden');
        detailsCard.classList.remove('hidden');
        document.getElementById('mess-owner-name').textContent = messDetails.name;
        document.getElementById('mess-owner-location').textContent = messDetails.location;
        document.getElementById('mess-owner-price').textContent = `₹${messDetails.price.toLocaleString('en-IN')}/month`;
        document.getElementById('mess-owner-menu').textContent = messDetails.menu;
    }
};


const renderListingsPage = (dataType) => {
     // Correctly handle pluralization for DB access
    const dataStoreKey = (dataType === 'messes') ? 'messes' : dataType; // Use 'messes', otherwise use 'pgs', 'notes', 'books'
    const data = DB[dataStoreKey] || [];

    document.getElementById('listings-title').textContent = LANDING_PAGE_FEATURES.find(f => f.options?.dataType === dataType)?.title || 'Listings';
    const grid = document.getElementById('listings-grid');
    grid.innerHTML = '';
    if (data.length === 0) {
        grid.innerHTML = `<p class="text-slate-500 col-span-full text-center py-8 bg-slate-100 rounded-lg">No items listed in this category yet.</p>`;
        return;
    }
    [...data].reverse().forEach(item => { // Show newest first
        let cardHtml = '';
        if (item.type === 'pg' || item.type === 'mess') {
             let occupancyBadge = '';
             if (item.type === 'pg' && item.occupancy) {
                 const occupancyText = formatOccupancy(item.occupancy);
                 const badgeColor = item.occupancy === 'girls' ? 'bg-pink-100 text-pink-700' : (item.occupancy === 'boys' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700');
                 occupancyBadge = `<span class="text-xs font-semibold px-2 py-1 ${badgeColor} rounded-full absolute top-3 right-3">${occupancyText}</span>`;
             }

             cardHtml = `
                <div class="listing-card bg-white rounded-xl border overflow-hidden shadow-sm relative">
                    <img src="${item.img || 'https://placehold.co/400x300/E2E8F0/94A3B8?text=No+Image'}" class="aspect-listing" alt="${item.name}">
                    ${occupancyBadge}
                    <div class="p-4">
                        <h3 class="text-xl font-bold text-slate-800">${item.name}</h3>
                        <p class="text-slate-600 text-sm">${item.location}</p>
                        <p class="text-2xl font-bold text-blue-600 mt-2">₹${item.price.toLocaleString('en-IN')}${item.type === 'pg' || item.type === 'mess' ? '/month' : ''}</p>
                        <button onclick="navigateTo('page-item-details', { itemId: ${item.id}, itemType: '${item.type}' })" class="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">View Details</button>
                    </div>
                </div>
            `;
        } else if (item.type === 'book' || item.type === 'note') {
            cardHtml = `
                <div class="listing-card bg-white rounded-xl border overflow-hidden shadow-sm">
                    <img src="${item.img || 'https://placehold.co/400x300/E2E8F0/94A3B8?text=No+Image'}" class="aspect-listing" alt="${item.name}">
                    <div class="p-4">
                        <h3 class="text-xl font-bold text-slate-800">${item.name}</h3>
                        <p class="text-slate-600 text-sm">Listed by ${item.ownerEmail.split('@')[0]}</p>
                        <p class="text-2xl font-bold text-green-600 mt-2">₹${item.price.toLocaleString('en-IN')}</p>
                        <button onclick='handleBuyAttempt(${JSON.stringify(item)})' class="w-full mt-4 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700">Buy Now</button>
                    </div>
                </div>
            `;
        }
        grid.innerHTML += cardHtml;
    });
    lucide.createIcons(); // Re-render Lucide icons for new content
};

const renderFeatures = (containerId, featuresArray) => {
    const grid = document.getElementById(containerId);
    if (!grid) return;
    grid.innerHTML = '';
    featuresArray.forEach(feature => {
        const card = document.createElement('div');
        card.className = 'feature-card bg-white p-6 rounded-xl border shadow-sm text-center cursor-pointer';
        card.innerHTML = `
            <div class="feature-icon-wrapper">
                <i data-lucide="${feature.icon || 'circle'}" class="w-8 h-8"></i>
            </div>
            <h3 class="text-xl font-bold text-slate-800">${feature.title}</h3>
            ${feature.desc ? `<p class="text-slate-500 text-sm mt-1">${feature.desc}</p>` : ''}
        `;
        card.onclick = () => navigateTo(feature.page, feature.options);
        grid.appendChild(card);
    });
    lucide.createIcons();
};

// Function to render the item details page
const renderItemDetailsPage = (itemId, itemType) => {
    if (!itemId || !itemType) {
        alert('Error: Item not found.');
        return goBack();
    }

    // --- THIS IS THE FIX ---
    // Correctly handle pluralization for DB access
    const dataStoreKey = (itemType === 'mess') ? 'messes' : `${itemType}s`; // Use 'messes' if type is 'mess', otherwise add 's'
    const dataStore = DB[dataStoreKey];
    // --- END OF FIX ---


    if (!dataStore) {
        alert('Error: Invalid item category.');
        return goBack();
    }

    const item = dataStore.find(i => i.id === itemId);
    if (!item) {
        alert('Error: Item could not be found.');
        return goBack();
    }

    // Find owner contact
    const owner = DB.users.find(u => u.email === item.ownerEmail);
    const contactInfo = owner ? (owner.contact || 'Not available') : 'Not available';

    // Populate common fields
    document.getElementById('details-img').src = item.img || 'https://placehold.co/800x500/E2E8F0/94A3B8?text=No+Image';
    document.getElementById('details-img').alt = item.name;
    document.getElementById('details-name').textContent = item.name;
    document.getElementById('details-location').textContent = item.location;
    document.getElementById('details-price').textContent = `₹${item.price.toLocaleString('en-IN')}/month`;
    document.getElementById('details-contact-info').textContent = contactInfo;

    const contactBtn = document.getElementById('details-contact-btn');
    contactBtn.onclick = () => {
        alert(`Owner Contact (Demo):\nPhone: ${contactInfo}`);
    };

    // Get section elements
    const featuresSection = document.getElementById('details-features-section');
    const menuSection = document.getElementById('details-menu-section');

    if (itemType === 'pg') {
        featuresSection.classList.remove('hidden');
        menuSection.classList.add('hidden');
        document.getElementById('details-occupancy').textContent = formatOccupancy(item.occupancy);
        document.getElementById('details-features').textContent = item.features || 'No features listed.';
    } else if (itemType === 'mess') {
        featuresSection.classList.add('hidden');
        menuSection.classList.remove('hidden');
        document.getElementById('details-menu').textContent = item.menu || 'No menu details provided.';
    }

    lucide.createIcons(); // Re-render icons
};


// --- FORM SUBMISSION LOGIC ---

// Generic image preview handler
const setupImageUpload = (inputId, previewId) => {
    const inputElement = document.getElementById(inputId);
    if (inputElement) {
        inputElement.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = (event) => {
                appState.uploadedImageBase64 = event.target.result;
                const previewElement = document.getElementById(previewId);
                if (previewElement) {
                    previewElement.src = appState.uploadedImageBase64;
                }
            };
            reader.readAsDataURL(file);
        });
    }
};


// Student - Sell Item Form
const saleForm = document.getElementById('sale-form');
if (saleForm) {
    saleForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!appState.uploadedImageBase64) {
            alert('Please upload an image for the item.');
            return;
        }
        const itemType = document.getElementById('sale-item-type').value; // 'book' or 'note'
        const dataStoreKey = `${itemType}s`; // 'books' or 'notes'

        const newItem = {
            id: Date.now(),
            type: itemType,
            name: document.getElementById('sale-item-title').value,
            price: parseInt(document.getElementById('sale-item-price').value),
            img: appState.uploadedImageBase64,
            ownerEmail: appState.currentUser.email
        };

        DB[dataStoreKey].push(newItem); // Add to global notes/books list
        appState.currentUser.listings.push(newItem); // Add to current user's personal listings

        alert('Item listed successfully!');
        e.target.reset(); // Clear the form
        document.getElementById('image-preview-sale-item').src = 'https://placehold.co/600x400/E2E8F0/94A3B8?text=Image+Preview'; // Reset image preview
        appState.uploadedImageBase64 = null; // Clear temp image
        navigateTo('page-dashboard-student'); // Go back to student dashboard
    });
}

// PG Owner - Add PG Form
const addPgForm = document.getElementById('add-pg-form');
if (addPgForm) {
    addPgForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!appState.uploadedImageBase64) {
            alert('Please upload an image for your PG.');
            return;
        }
        const newPG = {
            id: Date.now(),
            type: 'pg',
            name: document.getElementById('pg-name').value,
            location: document.getElementById('pg-location').value,
            occupancy: document.getElementById('pg-occupancy').value,
            price: parseInt(document.getElementById('pg-price').value),
            features: document.getElementById('pg-features').value,
            img: appState.uploadedImageBase64,
            ownerEmail: appState.currentUser.email
        };

        DB.pgs.push(newPG); // Add to global PGs list
        appState.currentUser.listings.push(newPG); // Add to owner's list

        alert('PG listed successfully!');
        e.target.reset();
        document.getElementById('image-preview-pg').src = 'https://placehold.co/600x400/E2E8F0/94A3B8?text=Image+Preview';
        appState.uploadedImageBase64 = null;
        navigateTo('page-dashboard-pgOwner');
    });
}

// Mess Owner - Add Mess Form
const addMessForm = document.getElementById('add-mess-form');
if (addMessForm) {
    addMessForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!appState.uploadedImageBase64) {
            alert('Please upload an image for your Mess.');
            return;
        }
        const newMess = {
            // id will be assigned later if new, or preserved if updating
            type: 'mess',
            name: document.getElementById('mess-name').value,
            location: document.getElementById('mess-location').value,
            price: parseInt(document.getElementById('mess-price').value),
            menu: document.getElementById('mess-menu').value,
            img: appState.uploadedImageBase64,
            ownerEmail: appState.currentUser.email
        };

        // Assuming one mess per owner for this demo model
        const existingMessIndexDB = DB.messes.findIndex(m => m.ownerEmail === appState.currentUser.email);
        const existingMessIndexUser = appState.currentUser.listings.findIndex(l => l.type === 'mess');

        let messToUpdate;

        if(existingMessIndexDB > -1) {
            // Update existing in global DB
            const existingItem = DB.messes[existingMessIndexDB];
            DB.messes[existingMessIndexDB] = {...existingItem, ...newMess, id: existingItem.id}; // Preserve original ID
            messToUpdate = DB.messes[existingMessIndexDB]; // Get the updated item
        } else {
            // Add new to global DB
            newMess.id = Date.now(); // Assign a new ID only if it's new
            DB.messes.push(newMess);
            messToUpdate = newMess; // The new item is the one to update/add in user list
        }

        // Update or add in user's listings
        if (existingMessIndexUser > -1) {
            appState.currentUser.listings[existingMessIndexUser] = messToUpdate;
        } else {
             appState.currentUser.listings.push(messToUpdate);
        }


        alert('Mess details updated successfully!');
        e.target.reset();
        document.getElementById('image-preview-mess').src = 'https://placehold.co/600x400/E2E8F0/94A3B8?text=Image+Preview';
        appState.uploadedImageBase64 = null;
        navigateTo('page-dashboard-messOwner');
    });
}


// --- BUY ATTEMPT HANDLER (for notes/books in listings page) ---
const handleBuyAttempt = (item) => {
    if (!appState.isLoggedIn) {
         alert("Please log in to buy items.");
         appState.intendedAction = { page: 'page-listings', options: { dataType: `${item.type}s` } };
         navigateTo('page-auth');
    } else if (appState.currentUser.role !== 'student') {
        alert('Only students can buy items from the marketplace.');
    }
    else {
        alert(`Purchase of "${item.name}" from ${item.ownerEmail.split('@')[0]} successful! (Demo)`);
    }
};


// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    // Render features for the landing page
    renderFeatures('features-grid-landing', LANDING_PAGE_FEATURES);

    // Setup image upload previews for relevant forms
    setupImageUpload('sale-item-image', 'image-preview-sale-item');
    setupImageUpload('pg-image', 'image-preview-pg');
    setupImageUpload('mess-image', 'image-preview-mess');

    // --- MOBILE NAVIGATION TOGGLE ---
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    if (mobileMenuButton) {
        mobileMenuButton.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
            // Toggle icon
            const icon = mobileMenuButton.querySelector('i');
            if (mobileMenu.classList.contains('hidden')) {
                icon.setAttribute('data-lucide', 'menu');
            } else {
                icon.setAttribute('data-lucide', 'x');
            }
            lucide.createIcons(); // Re-render the icon
        });
    }

    lucide.createIcons(); // Initialize Lucide icons
    navigateTo('page-landing'); // Start at the landing page
});